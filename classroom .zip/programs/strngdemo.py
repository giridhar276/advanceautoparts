name = "python programing"
print(name)
print()
print("I love",name)
print(1,2,3,4)
# string slicing
# string[start:stop:step]
print(name[0])
print(name[1])
print(name[0:8])
print(name[1:8])
print(name[0:18:2])
print(name[1:18:2])
print(name[1:17:4])
print(name[::])
print(name[:])
print(name[-1])
print(name[-2])
print(name[-4:-1])
print(name[::-1])


name = "python programming"
print(name.upper())
print(name)
print(name.lower())
print(name.center(40))
print(name.center(40,"*"))
print(name.isupper())
print(name.islower())
print(name.count("p"))
print(name.count("pro"))
print(name.split(" "))
print(name.replace('python','spark'))
print(name)
aname = "I love {} and {}"
print(aname.format('c','cpp'))
print(aname.format("python","unix"))

bname =  " python "
print(len(bname))
print(bname.strip())  # will remove whitespace at both ends
print(bname.lstrip())
print(bname.rstrip())
cname ='pythonp'
print(cname.strip('p'))



a = 100
b = 2

if a < b:
    print("A < B")
    print("Inside if")
    print("Stil inside if")
else:
    print("A> B")
    print("Inside else")
    print("still inside else")
print("regular program")


name = "python"
if name.startswith('p'):
    print("Its python")
else:
    print("its something else")
    
if name.isupper():
    print("String is defined in upper")
else:
    print("String is lower")


# for loop
#range(start,stop,step)
for val in range(1,11):
    print(val)
# display even numbers
for val in range(2,11,2):
    print(val)
# display numbers in reverse order
for val in range(10,0,-1):
    print(val)

name = 'python'
for char in name:
    print(char)

name = 'python'
for char in name[0:3]:
    print(char.upper())











