# fixed arguments
def display(a,b):
    print(a,b)
display(10,20)

#default arguments
def display(a = 0,b =0 ,c =0):
    print(a,b,c)
display()
display(10)
display(10,20)
display(10,20,30)

# keyword arguments
def display(b,a,c):
    print(a,b,c)
display(a=10,b=20,c=30)


# variable length
#If any object is prefixed with *... it becomes tuple
def display(*kargs):
    #print(kargs)
    for val in kargs:
        print(val)
display(10,20,30,12,34,56,543,5,5)


















