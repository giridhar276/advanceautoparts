
#- reading the file line by line using file object
# method 1
# fobj acts as file pointer or file reference or file handler
with open('languages.txt','r') as fobj:
    for line in fobj:
        print(line.strip().split(","))

# method 2
# reading using fobj.readlines() ----> output is the list
with open('languages.txt','r') as fobj:
    print(fobj.readlines())
    
    
#method3
# reading using fobj.read()  -----> output is the string
with open('languages.txt','r') as fobj:
    print(fobj.read())
    
# method4
import csv
with open('languages.txt','r') as fobj:
    # convert file ojbect to csv object
    reader = csv.reader(fobj)
    for line in reader:
        print(line)
   
    
#method5
import pandas 

df = pandas.read_csv('languages.txt')
print(df)

    
    










    
    
    
    
    
    
    
    
    
    
    
    
    
    
    