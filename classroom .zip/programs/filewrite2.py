# tradional way
# opening the file in write mode
fobj = open('languages.txt',"w")
# writing lines to the file
fobj.write('python programming\n')
fobj.write('scala programming\n')
fobj.close()

# context manager
#pythonic way
# if any line starts with keyword with .. we call it as context mgr
# file gets closed automatically when it moves out of indentaion
with open('languages.txt',"w") as fobj:
    fobj.write('python programming\n')
    fobj.write('scala programming\n')
print('out of file handling')