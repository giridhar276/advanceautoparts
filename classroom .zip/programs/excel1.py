
# import time
# filename = time.strftime("%d_%b_%Y.xlsx")
# print(filename)

import os
from openpyxl import Workbook
import time
filename = time.strftime("%d_%b_%Y.xlsx")
# grab the active worksheet
wb = Workbook()
ws = wb.active
try:
    for file in os.listdir():
        ws.append([file])
    wb.save(filename)
        
except Exception as err:
    print(err)
    