data = [10,10,10,20,30,40,50,10,10,10]

print(set(data))


aset = set()
for val in data:
    aset.add(val)
print(aset)


data = [10,10,10,20,30,40,50,10,10,10]
info = dict()
for val in data:
    info[val] = 1
print(info.keys())