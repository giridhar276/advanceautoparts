


alist = [10,20,30,40,50]
alist[0] = 1000
print('After replacing',alist)



atup = (10,20,30,40,50)
atup[0] = 10000
print('After replacing',atup)

# typecasting
# convert tuple to list 
alist = list(atup)
alist.append(36)
#reconverting back to tuple
atup = tuple(alist)
print('tuple elements are',atup)