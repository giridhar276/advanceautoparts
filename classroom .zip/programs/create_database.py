
import sqlite3
try:
    conn = sqlite3.connect('realestate.db')
    print("Opened database successfully")
    
    conn.close()
except Exception as err:
    print(err)
    
  
    
'''  
import pymysql
try:
    conn = pymysql.connect(host='127.0.0.1',port=3306,user='root',password='mypassword')
except Exception as err:
    print(err)
'''    