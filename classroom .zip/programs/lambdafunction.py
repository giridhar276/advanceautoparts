
def display(a,b):
    c = a+b
    return c
output = display(10,20)
print(output)


#nameless function
#lambda function
#lambda is the single liner function

#syntax
#functionname = lambda variables:expression
display = lambda x,y : x+y
output = display(10,20)
print(output)

## write a program to display the below output
alist = ["google","unix","oracle"]
#["www.google.com","www.unix.com","www.oracle.com"]

blist = []
for val in alist:
    blist.append("www." + val + ".com")
print(blist)

# map(function,iterable)
alist = ["google","unix","oracle"]
def appenddata(x):
    return "www." + x + ".com"
print(list(map(appenddata,alist)))


# map(function,iterable)
alist = ["google","unix","oracle"]
appenddata = lambda x : "www." + x + ".com"
print(list(map(appenddata,alist)))

# map(function,iterable)
alist = ["google","unix","oracle"]
print(list(map( lambda x : "www." + x + ".com",alist)))

















