# rreading csv and writing the output to excel file
import os
from openpyxl import Workbook
import time
import csv
output = time.strftime("realestate_%d_%b_%Y.xlsx")
wb = Workbook()
# grab the active worksheet
ws = wb.active
try:
    filename = "realestate.csv"
    #
    if os.path.isfile(filename) and os.path.getsize(filename) > 0:
        with open(filename) as fobj:
            reader = csv.reader(fobj)
            for record in reader:
                ws.append(record)
        # if the file is already existing.. delete the file first
        if os.path.exists(output):
            os.remove(output)
        wb.save(output)
except Exception as err:
    print(err)
    