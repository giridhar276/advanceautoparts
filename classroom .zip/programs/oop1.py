

class Employee:
    def displayEmployee(self):
        print("Employe name :","Ram")
        

# object creation of object initialization
emp1 = Employee()     # alist  = [10,20,30]
emp1.displayEmployee()


class Employee:
    def displayEmployee(self,name):
        self.name = name
        print("Employe name :",self.name)
        

# object creation of object initialization
emp1 = Employee()   
emp1.displayEmployee('Ram')

emp2 = Employee()   
emp2.displayEmployee('Rao')















