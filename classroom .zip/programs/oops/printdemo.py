




print(10,20,sep="      ",end= "\n\n\n\n")
print(30)