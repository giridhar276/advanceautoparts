
import os
import shutil
source = r'C:\Users\gsripath\Desktop\programs\source'
destination = r'C:\Users\gsripath\Desktop\programs\destination'
# we are logically moving to the source path
os.chdir(source)
for file in os.listdir(source): 
    shutil.copy( file,destination)
    print(file,"copied to ", destination)
    