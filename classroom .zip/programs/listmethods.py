alist = [12,23,34,57,21,46,68]
print("list elements are ",alist)

alist.append(100)
print("after appending",alist)
alist.append(1)
print("after appending",alist)

# add multiple elements
alist.extend([81,93,71])
print('after extending',alist)

#list.insert(index,position)
alist.insert(0,100)
print('After inserting',alist)

#list.pop(index)
alist.pop()
print('after pop',alist)  # last element will be removed
alist.pop(1)
print('after pop',alist)
#list.remove(value)
alist.remove(34)
print('after removing',alist)
#alist.remove(200)
#print('after removing',alist)

if 200 in alist:
    alist.remove(200)
    print('after removing',alist)
else:
    print("200 not found in list")
    
    
# ascending order
alist.sort()
print(alist)

alist.sort(reverse = True)
print('reverse sorted order :',alist)


alist = [39,21,34,32,91]
alist.reverse()
print(alist)




