

class Employee:
    def displayEmployee(self):
        print("Employe name :","Ram")
        

# object creation of object initialization
emp1 = Employee()     # alist  = [10,20,30]
emp1.displayEmployee()


class Employee:
    def displayEmployee(self,name,address):
        self.name = name
        self.address  = address

    def displayAddress(self):
        print("Name :",self.name)
        print("Address:",self.address)
        

# object creation of object initialization
emp1 = Employee()   
emp1.displayEmployee('Ram',"Hyderabad")
emp1.displayAddress()

emp2 = Employee()   
emp2.displayEmployee('Rao',"Mumbai")
emp2.displayAddress()














