# opening the file in write mode
fobj = open('languages.txt',"w")
# writing lines to the file
fobj.write('python programming\n')
fobj.write('scala programming\n')
# closing
fobj.close()

fobj = open('numbers.txt',"w")
# writing lines to the file
for val in range(1,10):
    fobj.write(str(val) + "\n" )
# closing
fobj.close()



#fobj = open(r'D:\trainings\ap\numbers.txt',"w")
#fobj = open('D:/trainings/ap/numbers.txt',"w")
fobj = open('D:\\trainings\\ap\\numbers.txt',"w")
# writing lines to the file
for val in range(1,10):
    fobj.write(str(val) + "\n" )
# closing
fobj.close()





















