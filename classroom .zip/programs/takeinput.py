


name = input('Enter any text :')
print(name)