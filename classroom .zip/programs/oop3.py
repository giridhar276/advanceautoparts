
class Employee:
    def __init__(self,name,address):
        self.name = name
        self.address  = address

    def displayAddress(self):
        print("Name :",self.name)
        print("Address:",self.address)
        

# object creation of object initialization
# using constructor
#  __init__ is the constructor
# constructor will be invoked automatically when the object is created
emp1 = Employee('Ram',"Hyderabad")   
emp1.displayAddress()

emp2 = Employee('Rao',"Mumbai")   
emp2.displayAddress()





