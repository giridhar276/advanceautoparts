import sqlite3

try:
    # create connection
    with sqlite3.connect('realestate.db') as conn:
        # dipslay message
        print ("Opened database successfully")
        # define query
        query = "insert into realestate(street,city) values('{}','{}')".format('Hitechcity','Hyderabad')
        # execute query
        conn.execute(query)
        
        # make changes permanent
        conn.commit()
        print("Records created successfully")
        # close the connection

except Exception as err:
    print(err)