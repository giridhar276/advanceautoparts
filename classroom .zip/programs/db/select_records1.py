

############### display records
import sqlite3

try:
    with sqlite3.connect('realestate.db') as conn:
        print("Opened database successfully")
        query = "SELECT * from realestate"
        cursor = conn.execute(query)
        for row in cursor:
            print(row)
        
        print("Operation done successfully")

except Exception as err:
    print(err)