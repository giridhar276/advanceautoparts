import sqlite3
class DBSelect :
    def __init__(self,db):
        self.db=db
    def connectDB(self):
        try:
            self.conn = sqlite3.connect(self.db)
        except Exception as err:
            print(err)
    def executeDB(self):
        try:
            self.query = "select * from realestate"
            self.cursor = self.conn.execute(self.query)
        except Exception as err:
            print(err)
    def displayRecords(self):
        try:
            for row in self.cursor:
                print(row)
        except Exception as err:
            print(err)
db1 = DBSelect("realestate.db")
db1.connectDB()
db1.executeDB()
db1.displayRecords()    
