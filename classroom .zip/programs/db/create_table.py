import sqlite3

try:
    with sqlite3.connect('realestate.db') as conn:
        print("Opened database successfully")
        
        conn.execute('''CREATE TABLE realestate
                 (
                 street CHAR(50) NOT NULL,
                 city   CHAR(50) NOT NULL);       
                 ''')        
        print("Table created successfully")
    
except Exception as err:
    print(err)