

import getpass
username = input('Enter username :')
password = getpass.getpass()
print(password)






#pwinput is the third party library
import pwinput
password = pwinput.pwinput()
print(password)















