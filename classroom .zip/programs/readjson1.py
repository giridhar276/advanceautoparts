import json

try:
    with open('sample4.json') as fobj:
        # converting fobj to dictionary
        data = json.load(fobj)
        for item in data['people']:
            info = list(item.values())       
            #info[3] = str(info[3])
            info = list(map(lambda x: str(x), info))
            # convert list to the string
            info = ",".join(info)
            print(info)
            
except Exception as err:
    print(err)    