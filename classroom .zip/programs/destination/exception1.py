



try:
    filename = input("Enter any filename:")
    with open(filename,'r') as fobj:
        for line in fobj:
            line = line.strip()
            line = line.replace('SACRAMENTO','HYDERABAD')
            print(line)
except FileNotFoundError as e:
    print("file is not found..pl check")
    print("system error :",e)
except TypeError as err:
    print("Invalid operation")
    print("system error :",err)
except (ValueError,KeyError) as err:
    print("Invalid index")
    print(err)
except  Exception as err:
    print(err)


for val in range(1,10):
    print(val)    