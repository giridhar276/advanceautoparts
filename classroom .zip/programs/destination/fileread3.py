'''
Write a Python program to read realestate.csv and display all the 
UNIQUE cities and the count of unique cities.

SACRAMENTO
RANCHO CORDOVA
RIO LINDA
..
..
'''

import csv
citySet = set()
with open('realestate.csv','r') as fobj:
    # convert file ojbect to csv object
    reader = csv.reader(fobj)
    # processing
    for line in reader:
        city  = line[1]
        citySet.add(city)
    #displaying
    for city in citySet:
        print(city)
        
        
    
import csv
cityDict = dict()
with open('realestate.csv','r') as fobj:
    # convert file ojbect to csv object
    reader = csv.reader(fobj)
    # processing
    for line in reader:
        city  = line[1]
        cityDict[city] =1
    #displaying
    for city in cityDict:
        print(city)        
        
        
        
        
        
        
        
        
        