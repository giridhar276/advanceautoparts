book = {"chap1":10 ,"chap2":20 ,"chap3":30}
print(book)
#accessing individual value
print(book["chap1"]) # 10
print(book["chap2"]) # 20
# creating new key-value pairs
book["chap4"] = 40
book["chap5"] = 50
print(book)
# display the keys only
print(book.keys())

for key in book.keys():
    print(key)
    
# display the value only
print(book.values())

for v in book.values():
    print(v)
    
# display key,value
for k,v in book.items():
    print(k,v)
    
    
    
#print(book["chap10"])
# method1 - to check key is existing or not
if "chap10" in book:
    print(book["chap10"])
else:
    print("key not found")
    
print(book.get("chap10")) # if chap10 is not existing it returns None
print(book.get("chap1"))


book = {'chap1': 10, 'chap2': 20, 'chap3': 30}
newbook = {"chap4":40 ,"chap5":50,"chap1":100}

finalbook  = {**book,**newbook}
print(finalbook)


# updating book
book.update(newbook)   # all the key,values of newbook will be updated with book
print(book)


alist =[10,20]
blist = [30,40]
finalist = alist + blist
print(finalist)

firstName = 'rita'
lastName = 'sharma'
finalstring = firstName + lastName
print(finalstring)



















    
    
    
    
    
    
    
    