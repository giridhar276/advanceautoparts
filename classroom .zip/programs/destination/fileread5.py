
'''
Write a Python program to read realestate.csv and replace all 
the lines containing SACRAMENTO with HYDERABAD and display on the screen
'''

with open('realestate.csv','r') as fobj:
    for line in fobj:
        line = line.strip()
        line = line.replace('SACRAMENTO','HYDERABAD')
        print(line)



# writing the output to the file
with open('realestate.csv','r') as fobj:
    with open('realhyd.csv','w') as fw:
        for line in fobj:
            line = line.strip()
            line = line.replace('SACRAMENTO','HYDERABAD')
            fw.write(line + "\n")