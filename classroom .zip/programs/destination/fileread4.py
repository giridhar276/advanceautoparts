
'''
 Write a Python program to read realestate.csv and display the count of an individual city.
 
SACRAMENTO      - xxx times
RANCHO CORDOVA     xx times
RIO LINDA          xx times
..
..
''' 


import csv
cityList = list()
with open('realestate.csv','r') as fobj:
    # convert file ojbect to csv object
    reader = csv.reader(fobj)
    # processing
    for line in reader:
        city  = line[1]
        cityList.append(city)
    #displaying
    for city in set(cityList):
        print(city.ljust(20), cityList.count(city),"times")
        